import 'package:projet4/data/data_provider/dataProvider.dart';

class SituationRepository {
  void main() {
    DataProvider.getSituations();
  }
}
